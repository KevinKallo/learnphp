<?php $__env->startSection('content'); ?>
    <div class="container mx-auto">
        <div class="flex flex-row flex-wrap">
            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="basis-1/4 mb-4">
                    <div class="card w-96 bg-base-100 shadow-xl h-full">
                        
                        <div class="card-body">
                            <h2 class="card-title"><?php echo e($article->title); ?></h2>
                            <p><?php echo e($article->snippet); ?></p>
                            <div class="card-actions justify-end">
                                <button class="btn btn-primary">Buy Now</button>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partials.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kevin.kallo\mm-21\learnphp\blog\resources\views/welcome.blade.php ENDPATH**/ ?>