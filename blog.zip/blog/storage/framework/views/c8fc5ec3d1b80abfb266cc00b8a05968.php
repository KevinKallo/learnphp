<li><a href="/">Home</a></li>
<li><a href="/about">About</a></li>
<?php /**PATH C:\Users\kevin.kallo\mm-21\learnphp\blog\resources\views/partials/links.blade.php ENDPATH**/ ?>