<?php $__env->startSection('content'); ?>
    <h1 class="text-3xl font-bold underline">
        About
    </h1>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('partials.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kevin.kallo\mm-21\learnphp\blog\resources\views/about.blade.php ENDPATH**/ ?>